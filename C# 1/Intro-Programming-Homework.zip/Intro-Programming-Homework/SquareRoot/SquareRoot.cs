﻿using System;


namespace SquareRoot
{
    class SquareRoot
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.Sqrt(12345));
        }
    }
}
