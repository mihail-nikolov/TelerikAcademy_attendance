﻿using System;


namespace PrintNumbers
{
    class PrintNumbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1\n101\n1001");
        }
    }
}
