﻿using System;


namespace HelloCSharp
{
    class HelloCSharp
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello C#");
        }
    }
}
