﻿using System;


namespace PrintMyName
{
    class PrintMyName
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mihail");
        }
    }
}
