﻿using System;


namespace PrintFLName
{
    class PrintFLName
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mihail\nNikolov");
        }
    }
}
